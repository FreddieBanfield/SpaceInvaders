package com.virlaity.src;

import java.awt.Canvas;
import java.awt.Dimension;

import javax.swing.JFrame;


public class Window extends Canvas{

	private static final long serialVersionUID = 1L;
	
	public Window(int width, int height, String title, Game game){
		JFrame gameFrame = new JFrame(title);
		
		gameFrame.setPreferredSize(new Dimension(width, height));
		gameFrame.setMaximumSize(new Dimension(width, height));
		gameFrame.setMinimumSize(new Dimension(width, height));
		
	
		gameFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gameFrame.setResizable(false);
		gameFrame.setLocationRelativeTo(null);
		gameFrame.add(game);
		gameFrame.setVisible(true);
		game.start();
	}

}
