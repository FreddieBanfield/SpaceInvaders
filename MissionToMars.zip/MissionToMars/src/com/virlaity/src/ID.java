package com.virlaity.src;

public enum ID {
	
	Player(),
	Meteor(),
	FighterMK1(),
	Asteroid(),
	MK1Bullet(),
	Bullet(),
	HomingMissile();
}
