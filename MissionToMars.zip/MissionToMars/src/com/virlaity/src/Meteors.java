package com.virlaity.src;


import java.awt.Graphics;
import java.awt.Image;


import java.awt.Rectangle;

import javax.swing.ImageIcon;

public class Meteors extends GameObject{

	int hp = 10;
	
	boolean destroy = false;
	
	private HUD hud;
	
	//Images
	private double imageNum = 1;
	private String meteorImage1 = "/images/Meteor1.png";
	private String meteorImage2 = "/images/Meteor2.png";
	private String meteorImage3 = "/images/Meteor3.png";
	
	private double imageExplosionNum = 1;
	private String meteorExplosion1 = "/images/MeteorExplosion1.png";
	private String meteorExplosion2 = "/images/MeteorExplosion2.png";
	private String meteorExplosion3 = "/images/MeteorExplosion3.png";
	private String meteorExplosion4 = "/images/MeteorExplosion4.png";
	private String meteorExplosion5 = "/images/MeteorExplosion5.png";
	private String meteorExplosion6 = "/images/MeteorExplosion6.png";
	private String meteorExplosion7 = "/images/MeteorExplosion7.png";
	private String meteorExplosion8 = "/images/MeteorExplosion8.png";
	
	//Audio
	private 
	
	Handler handler;
	
	public Meteors(int x, int y, ID id, Handler handler, HUD hud) {
		super(x, y, id);
		this.handler = handler;
		this.hud = hud;
		velY = 2;
	}

	public Rectangle getBounds(){
		return new Rectangle((int)x, (int)y, 18, 28);
	}
	
	
	public void tick() {
		x += velX;
		y += velY;
		
		collision();
		destroyInstance();
	}
	
	
	
	private void collision(){
		for(int i = 0; i <handler.object.size();i++){
			
			GameObject tempObject = handler.object.get(i);
			
			if(tempObject.getID() == ID.Bullet){
				if(getBounds().intersects(tempObject.getBounds()) && (destroy != true)){
					//Collision Code
					handler.removeObject(tempObject);
					hp = hp - Bullet.damage;
					if (hp <= 0){
						hud.score = hud.score + 10;
						
						destroy = true;
					}
				}
			}
			if(tempObject.getID() == ID.HomingMissile){
				if(getBounds().intersects(tempObject.getBounds()) && (destroy != true)){
					//Collision Code
					handler.removeObject(tempObject);
					hp = hp - HomingMissile.damage;
					if (hp <= 0){
						hud.score = hud.score + 10;
						
						destroy = true;
					}
				}
			}
			if(tempObject.getID() == ID.Player){
				if(getBounds().intersects(tempObject.getBounds())){
					handler.removeObject(this);
					if(destroy == true){
						HUD.HEALTH -= 5;
					}else{
						HUD.HEALTH -= 10;
					}
				}
			}
		}
	}

	private void destroyInstance(){
		if(y > Game.HEIGHT){
			handler.removeObject(this);
			System.gc();
		}
	}

	public void render(Graphics g) {
		if(destroy == false){
		g.drawImage(getMeteorImage(), (int)x, (int)y, null);
		}if(destroy == true){
			g.drawImage(explosionAnnimation(), (int)x - 56,(int) y- 50, null);
			//velY = 0;
		}
	
		
	}

	public Image getMeteorImage(){
		if(imageNum <= 1.9 && imageNum >= 1){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorImage1));
			imageNum = imageNum + Game.animationSpeed;
			return i.getImage();
		}else if(imageNum >1.9 && imageNum < 2.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorImage2));
			imageNum = imageNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageNum >2.9 && imageNum < 3.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorImage3));
			imageNum = imageNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageNum >3.9 && imageNum < 4.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorImage2));
			imageNum = imageNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageNum > 4.9){
			imageNum = 1;
		}
		return null;
	}
	
	private Image explosionAnnimation(){
		if(imageExplosionNum <= 1.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorExplosion1));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if(imageExplosionNum >1.9 && imageExplosionNum< 2.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorExplosion2));
			imageExplosionNum = imageExplosionNum  + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >2.9 && imageExplosionNum < 3.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorExplosion3));
			imageExplosionNum = imageExplosionNum +  Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >3.9 && imageExplosionNum < 4.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorExplosion4));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >4.9 && imageExplosionNum < 5.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorExplosion5));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >5.9 && imageExplosionNum < 6.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorExplosion6));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >6.9 && imageExplosionNum < 7.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorExplosion7));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >7.9 && imageExplosionNum < 8.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorExplosion8));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if(imageExplosionNum >8.9){
			handler.removeObject(this);
		}
		return null;
		
	}

}
