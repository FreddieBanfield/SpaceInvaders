package com.virlaity.src;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;

public class HUD {

	
	public static float HEALTH = 100f;
	public static double GUNHEAT = 0;
	public static boolean gunFireDetection = false;
	public static boolean gunReset = false;
	public static boolean laser = false;
	public static boolean rocket = false;
	
	private double greenValue = 255;
	private double redValue = 75;
	private double gunResetNum = 0.2;
	
	private double redValue2 = 244;
	private double greenValue2 = 0;
	private double blueValue2 = 0;
	
	int score = 0;
	private int EnemyTotCount = 1;
	
	private String bulletImage = "/images/Bullet.png";
	private String missileImage = "/images/Rocket1.png";
	
	public void tick(){
		HEALTH = Game.clamp(HEALTH, 0, 100);
		greenValue = Game.clamp((int)greenValue, 0, 255);
		
		greenValue = HEALTH*2.25;
		redValue = (100 -HEALTH) * 2.5;
		
		if(gunFireDetection == true && gunReset == false){
			if (laser == true){
				GUNHEAT= GUNHEAT + 10;
			}else if (rocket == true){
				GUNHEAT= GUNHEAT + 100;
			}
			gunFireDetection = false;
		}if(GUNHEAT < 100){
			
			GUNHEAT = GUNHEAT - gunResetNum;
		}else if(GUNHEAT >= 100){
			redValue2 = 64;
			greenValue2 = 0;
			blueValue2 = 0;
			
			gunResetNum = 1;
			GUNHEAT = 99;
			gunReset = true;
		}
		if(GUNHEAT <= 0){
			redValue2 = 244;
			greenValue2 = 0;
			blueValue2 = 0;
			
			GUNHEAT = 0;
			gunResetNum = 0.2;
			gunReset = false;
		}

		
	}
	
	public void render(Graphics g){
		//Back of top display
		g.setColor(Color.DARK_GRAY);
		g.fillRect(0,0,330,50);
		//Front of top display
		g.setColor(Color.GRAY);
		g.fillRect(5,5,320,40);
		//Score slot
		g.setColor(Color.DARK_GRAY);
		g.fillRect(10,10,125,30);
		g.setColor(Color.WHITE);
		g.drawString("Score: " + score,15,30);
		//Weapon 1
		g.setColor(Color.DARK_GRAY);
		g.fillRect(200,10,30,30);
		if(KeyInput.weaponNum == 1){
			g.setColor(Color.RED);
			g.drawRect(200,10,30,30);
		}
		//Weapon 2
		g.setColor(Color.DARK_GRAY);
		g.fillRect(240,10,30,30);
		if(KeyInput.weaponNum == 2){
			g.setColor(Color.RED);
			g.drawRect(240,10,30,30);
		}
		//Weapon 3
		g.setColor(Color.DARK_GRAY);
		g.fillRect(280,10,30,30);
		if(KeyInput.weaponNum == 3){
			g.setColor(Color.RED);
			g.drawRect(280,10,30,30);
		}
		
		
		//Left wall
		g.setColor(Color.DARK_GRAY);
		g.fillRect(0,50,5,521);
		//Right wall
		g.setColor(Color.DARK_GRAY);
		g.fillRect(325,50,5,521);
		//Bottom
		g.setColor(Color.DARK_GRAY);
		g.fillRect(0,561,330,15);
		
		
		//Back of life slot
		g.setColor(Color.DARK_GRAY);
		g.fillRect(0,516,55,55);
		//Front of life slot
		g.setColor(Color.GRAY);
		g.fillRect(5,521,45,45);
		//Life Slot
		g.setColor(Color.DARK_GRAY);
		g.fillRect(10,526,35,35);
		//Health
		g.setColor(new Color((int)redValue, (int)greenValue, 0));
		g.fillRect(11,560 - ((int)HEALTH / 3),33,(int)HEALTH / 3);
		//Level
		g.setColor(Color.WHITE);
		g.drawString("Enemies: " + EnemyTotCount, 260, 545);
		
		
		//Back of gun heat bar
		g.setColor(Color.DARK_GRAY);
		g.fillRect(55,531,110,35);
		//Front of gun heat bar
		g.setColor(Color.GRAY);
		g.fillRect(50,536,110,30);
		//Front of gun heat bar
		g.setColor(Color.DARK_GRAY);
		g.fillRect(54,540,102,22);
		//gun heat bar
		g.setColor(new Color((int) redValue2, (int) greenValue2, (int)blueValue2));  
		g.fillRect(55,541,(int) GUNHEAT,20);
		
		
		
		
		g.drawImage(getBulletImage(), (int) 214, (int) 17, null);
		g.drawImage(getMissileImage(), (int) 249, (int) 11, null);
		
	}
	
	public void score(int score){
		this.score = score;
	}
	
	public int getScore(){
		return score;
	}
	
	public int getEnemyTotCount(){
		return EnemyTotCount;
	}
	
	public void setEnemyTotCount(int level){
		this.EnemyTotCount = level;
	}
	

	
	public Image getBulletImage(){
		ImageIcon i = new ImageIcon(getClass().getResource(bulletImage));
		return i.getImage();
	}
	
	public Image getMissileImage(){
		ImageIcon i = new ImageIcon(getClass().getResource(missileImage));
		return i.getImage();
	}
}
