package com.virlaity.src;



import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;


import java.awt.Rectangle;
import javax.swing.ImageIcon;

public class HomingMissile extends GameObject{
	
	boolean destroy = false;
	static int damage = 50;
	

	

	
	private HUD hud;
	
	//Images
	//private double imageNum = 1;
	private String HMissileImage = "/images/ .png";
	
	private double imageExplosionNum = 1;
	private String rocket1  = "/images/Rocket1.png";
	private String rocket2  = "/images/Rocket2.png";
	private String rocket3  = "/images/Rocket3.png";
	private String rocket4  = "/images/Rocket4.png";
	private String rocket5  = "/images/Rocket5.png";
	private String rocket6  = "/images/Rocket6.png";
	private String rocket7  = "/images/Rocket7.png";
	private String rocket8  = "/images/Rocket8.png";
	private String rocket9  = "/images/Rocket9.png";
	


	
	
	//Audio
	private Handler handler;
	private GameObject FMK1;
	private GameObject Meteor;

	
	public HomingMissile(int x, int y, ID id, Handler handler, HUD hud) {
		super(x, y, id);
		this.handler = handler;
		this.hud = hud;
		


		}
		
		
		
	

	public Rectangle getBounds(){
		return new Rectangle((int)x, (int)y, 10, 10);
	}
	
	
	public void tick() {
		x += velX;
		y += velY;

		
		
			//velX = 0;
			//velY = -2;


		MoveXY();
		collision();
		destroyInstance();
		int dir =  90;
		double radians = dir*Math.PI/180.0;
		velX += (0.05*Math.cos(radians));
		velY -=  (0.05 * Math.sin(radians));

	}
	
	private void MoveXY(){
		
	}
	

	
	private void collision(){
		for(int i = 0; i < handler.object.size();i++){
			
			GameObject tempObject = handler.object.get(i);
			
			if(tempObject.getID() == ID.Meteor){
				if(getBounds().intersects(tempObject.getBounds()) && (destroy != true)){

				}
			}
			
			if(tempObject.getID() == ID.FighterMK1){
				if(getBounds().intersects(tempObject.getBounds())){

				}
			}
		}
	}

	private void destroyInstance(){
		if(y < 40){
			handler.removeObject(this);
			System.gc();
		}
		if(y > 610){
			handler.removeObject(this);
			System.gc();
		}
		if(x < -10){
			handler.removeObject(this);
			System.gc();
		}
		if(x > 346){
			handler.removeObject(this);
			System.gc();
		}
	}

	public void render(Graphics g) {
		if(destroy == false){

			g.drawImage(rocketAnnimation(), (int)x - 4,(int) y-15 , null);
		}if(destroy == true){
			//g.drawImage(explosionAnnimation(), (int)x - 56,(int) y- 50, null);
			//velY = 0;
		}
	
	}

	public Image getFighterMK1Image1(){

			ImageIcon i = new ImageIcon(getClass().getResource(HMissileImage));
			return i.getImage();
	}
	
	private Image rocketAnnimation(){
		if(imageExplosionNum <= 1.9){
			ImageIcon i = new ImageIcon(getClass().getResource(rocket1));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if(imageExplosionNum >1.9 && imageExplosionNum< 2.9){
			ImageIcon i = new ImageIcon(getClass().getResource(rocket2));
			imageExplosionNum = imageExplosionNum  + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >2.9 && imageExplosionNum < 3.9){
			ImageIcon i = new ImageIcon(getClass().getResource(rocket3));
			imageExplosionNum = imageExplosionNum +  Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >3.9 && imageExplosionNum < 4.9){
			ImageIcon i = new ImageIcon(getClass().getResource(rocket4));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >4.9 && imageExplosionNum < 5.9){
			ImageIcon i = new ImageIcon(getClass().getResource(rocket5));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >5.9 && imageExplosionNum < 6.9){
			ImageIcon i = new ImageIcon(getClass().getResource(rocket6));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >6.9 && imageExplosionNum < 7.9){
			ImageIcon i = new ImageIcon(getClass().getResource(rocket7));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >7.9 && imageExplosionNum < 8.9){
			ImageIcon i = new ImageIcon(getClass().getResource(rocket8));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >8.9 && imageExplosionNum < 9.9){
			ImageIcon i = new ImageIcon(getClass().getResource(rocket9));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if(imageExplosionNum >9.9){
			imageExplosionNum = 7;  
		}
		return null;
		
	}
	
	/*private Image explosionAnnimation(){
		if(imageExplosionNum <= 1.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorExplosion1));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if(imageExplosionNum >1.9 && imageExplosionNum< 2.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorExplosion2));
			imageExplosionNum = imageExplosionNum  + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >2.9 && imageExplosionNum < 3.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorExplosion3));
			imageExplosionNum = imageExplosionNum +  Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >3.9 && imageExplosionNum < 4.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorExplosion4));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >4.9 && imageExplosionNum < 5.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorExplosion5));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >5.9 && imageExplosionNum < 6.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorExplosion6));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >6.9 && imageExplosionNum < 7.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorExplosion7));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >7.9 && imageExplosionNum < 8.9){
			ImageIcon i = new ImageIcon(getClass().getResource(meteorExplosion8));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if(imageExplosionNum >8.9){
			handler.removeObject(this);
		}
		return null;
		
	}*/

}
