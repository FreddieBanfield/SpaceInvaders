package com.virlaity.src;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;

import javax.swing.ImageIcon;

public class Bullet extends GameObject{

	static int damage = 10;
	
	private String bulletImage = "/images/Bullet.png";
	Handler handler;
	
	public Bullet(int x, int y, ID id, Handler handler){
		super(x, y, id);
		this.handler = handler;
		velX = 0;
		velY = -6;
	}
	
	public Rectangle getBounds(){
		return new Rectangle((int)x, (int)y, 4, 16);
	}
	
	public void tick(){
		x += velX;
		y += velY;
		
		destroyInstance();
	}

	private void destroyInstance(){
		if(y < 0){
			handler.removeObject(this);
			System.gc();
		}
	}
	
	public void render(Graphics g){
		// TODO Auto-generated method stub
		if(id == ID.Bullet)g.drawImage(getPlayerImage(),(int) x,(int) y, null);

	}
	
	public Image getPlayerImage(){
		ImageIcon i = new ImageIcon(getClass().getResource(bulletImage));
		return i.getImage();
	}
}
