package com.virlaity.src;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;

import javax.swing.ImageIcon;

public class MK1Bullet extends GameObject{

	static int damage = 10;
	
	private String MK1bulletImage = "/images/FighterMK1Bullet.png";
	Handler handler;
	
	public MK1Bullet(int x, int y, ID id, Handler handler){
		super(x, y, id);
		this.handler = handler;
		velX = 0;
		velY = 6;
	}
	
	public Rectangle getBounds(){
		return new Rectangle((int)x, (int)y, 4, 16);
	}
	
	public void tick(){
		x += velX;
		y += velY;
		
		collision();
		destroyInstance();
	}
	
	private void collision(){
		for(int i = 0; i <handler.object.size();i++){
			
			GameObject tempObject = handler.object.get(i);
			
			if(tempObject.getID() == ID.Player){
				if(getBounds().intersects(tempObject.getBounds())){
					//Collision Code
					handler.removeObject(this);
					HUD.HEALTH = HUD.HEALTH - 25;
				}
			}
		}
	}

	private void destroyInstance(){
		if(y > 700){
			handler.removeObject(this);
			System.gc();
		}
	}
	
	public void render(Graphics g){
		// TODO Auto-generated method stub
		if(id == ID.MK1Bullet)g.drawImage(getBulletImage(),(int) x,(int) y, null);

	}
	
	public Image getBulletImage(){
		ImageIcon i = new ImageIcon(getClass().getResource(MK1bulletImage));
		return i.getImage();
	}
}
