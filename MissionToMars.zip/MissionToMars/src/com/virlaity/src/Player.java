package com.virlaity.src;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;

import javax.swing.ImageIcon;


public class Player extends GameObject {
	
	public static int move = 1;
	
	//Images
	private double imageNum = 1;
	private String SpaceShipIdle1 = "/images/SpaceShipIdle1.png";
	private String SpaceShipIdle2 = "/images/SpaceShipIdle2.png";
	private String SpaceShipIdle4 = "/images/SpaceShipIdle4.png";
	
	private String SpaceShipMove2 = "/images/SpaceShipMove2.png";
	private String SpaceShipMove3 = "/images/SpaceShipMove3.png";

	private String playerImage = "/images/SpaceShip.png";
	Handler handler = new Handler();
	
	
	public Player(int x, int y, ID id) {
		super(x, y, id);

	}

	public Rectangle getBounds(){
		return new Rectangle((int)x, (int)y, 21, 24);
	}
	
	
	public void tick() {
		x += velX;
		y += velY;
		
		x = Game.clamp((int)x, 5, Game.WIDTH - 33);
		y = Game.clamp((int)y, 75, Game.HEIGHT - 64);
		
	}
	
	public Image getPlayerIdleImage(){
		if(imageNum <= 1.9 && imageNum >= 1){
			ImageIcon i = new ImageIcon(getClass().getResource(SpaceShipIdle1));
			imageNum = imageNum + Game.animationSpeed;
			return i.getImage();
		}else if(imageNum >1.9 && imageNum < 2.9){
			ImageIcon i = new ImageIcon(getClass().getResource(SpaceShipIdle2));
			imageNum = imageNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageNum >2.9 && imageNum < 3.9){
			ImageIcon i = new ImageIcon(getClass().getResource(SpaceShipIdle1));
			imageNum = imageNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageNum >3.9 && imageNum < 4.9){
			ImageIcon i = new ImageIcon(getClass().getResource(SpaceShipIdle4));
			imageNum = imageNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageNum > 4.9){
			imageNum = 1;
		}
		return null;
	}
	
	public Image getPlayerMoveImage(){
		if(imageNum <= 1.9 && imageNum >= 1){
			ImageIcon i = new ImageIcon(getClass().getResource(SpaceShipMove2));
			imageNum = imageNum + Game.animationSpeed;
			return i.getImage();
		}else if(imageNum >1.9 && imageNum < 2.9){
			ImageIcon i = new ImageIcon(getClass().getResource(SpaceShipMove3));
			imageNum = imageNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageNum > 2.9){
			imageNum = 1;
		}
		return null;
	}
	
	public Image getPlayerImage(){
			ImageIcon i = new ImageIcon(getClass().getResource(playerImage));
			return i.getImage();

	}
	

	public void render(Graphics g) {
		// TODO Auto-generated method stub
		if(move== 1){
		g.drawImage(getPlayerIdleImage(), (int)x, (int)y, null);
		}if(move == 2){
			g.drawImage(getPlayerMoveImage(), (int)x,(int) y, null);
		}if(move == 3){
			g.drawImage(getPlayerImage(), (int)x, (int)y, null);

		}
	}

	
	


}
