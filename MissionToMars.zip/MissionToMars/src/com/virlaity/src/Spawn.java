package com.virlaity.src;

import java.util.Random;

public class Spawn {

	private Handler handler;
	private HUD hud;
	private Random r = new Random();
	
	private int spawnTime = 0;
	private int scoreTimer = 0;
	private int totalSpawnTime = 100;
	private int fighterMK1Spawner = 0 ;
	
	public Spawn(Handler handler, HUD hud){
		this.handler = handler;
		this.hud = hud;
	}
	
	public void tick(){
		spawnTime++;
		scoreTimer++;
		
		if(scoreTimer == 50){
			scoreTimer = 0;
			hud.score++;
		}
		
		if(spawnTime >= totalSpawnTime){
			if(totalSpawnTime <= 30){
				totalSpawnTime = 30;
				
			}else totalSpawnTime = totalSpawnTime - 2;
			spawnTime = 0;
			fighterMK1Spawner++;
			hud.setEnemyTotCount(hud.getEnemyTotCount() + 1);//Enemy Count
			//Spawns Meteor
			handler.addObject(new Meteors(r.nextInt(Game.WIDTH - 32), -10, ID.Meteor, handler, hud)); //Meteor
			
		}
		if(fighterMK1Spawner == 10){
			fighterMK1Spawner = 0;
			hud.setEnemyTotCount(hud.getEnemyTotCount() + 1);//Enemy Count
			handler.addObject(new FighterMK1(r.nextInt( (Game.WIDTH - 32)), -10, ID.FighterMK1, handler, hud)); //FighterMK1
		}
		
	}
}
