package com.virlaity.src;

public class Sheild {
	
	private Handler handler;
	private HUD hud;
	
	public Sheild(int x, int y, ID id, Handler handler, HUD hud) {
		//super(x, y, id);
		this.handler = handler;
		this.hud = hud;
		}
	
	public void tick(){
		
	}
	
	public void render(){
		
	}
}
