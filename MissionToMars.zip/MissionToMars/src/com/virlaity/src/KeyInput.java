package com.virlaity.src;


import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;



public class KeyInput extends KeyAdapter{
	
	public static int weaponNum = 1;
	private static Handler handler;
	private int SDNum = 0; //Slow Down Number]
	private int shotNum = 1;//Number of shots in a row
	private boolean[] keyDown = new boolean[4];
	
	
	
	public KeyInput(Handler handler){
		KeyInput.handler = handler;
		
		keyDown[0]=false;
		keyDown[1]=false;
		keyDown[2]=false;
		keyDown[3]=false;
		
	}
	
	
	public void keyPressed(KeyEvent e){
		int key = e.getKeyCode();
		
		
		for(int i = 0; i < handler.object.size(); i++){
			GameObject tempObject = handler.object.get(i);
			
			/*if(tempObject.getID() == ID.Player){
				//Key Events for Player1
				
				if(key == KeyEvent.VK_W) tempObject.setVelY(-3);
				if(key == KeyEvent.VK_S) tempObject.setVelY(3);
				if(key == KeyEvent.VK_A) tempObject.setVelX(-3);
				if(key == KeyEvent.VK_D) tempObject.setVelX(3);

			}*/
			if(tempObject.getID() == ID.Player){
				//Key Events for Player2
				
				if(key == KeyEvent.VK_UP) { tempObject.setVelY(-3); keyDown[0]=true; Player.move = 2;}
				if(key == KeyEvent.VK_DOWN){ tempObject.setVelY(3); keyDown[1]=true; Player.move = 3;}
				if(key == KeyEvent.VK_LEFT){ tempObject.setVelX(-3); keyDown[2]=true; Player.move = 1;}
				if(key == KeyEvent.VK_RIGHT){ tempObject.setVelX(3); keyDown[3]=true; Player.move = 1;}
				if(key == KeyEvent.VK_1){ weaponNum = 1;}
				if(key == KeyEvent.VK_2){ weaponNum = 2;}
				if(key == KeyEvent.VK_3){ weaponNum = 3;}
				if(key == KeyEvent.VK_SPACE && shotNum == 1 && HUD.GUNHEAT < 100 && HUD.gunReset == false) {
					if(weaponNum == 1){
						handler.addObject(new Bullet((int)tempObject.getX() + 8,(int)tempObject.getY() -10, ID.Bullet, handler)); 
						HUD.laser = true;
						HUD.rocket = false;
					}else if(weaponNum == 2){
						handler.addObject(new HomingMissile((int)tempObject.getX() + 8,(int)tempObject.getY() -10, ID.HomingMissile, handler, null));
						HUD.laser = false;
						HUD.rocket = true;
					}else if(weaponNum == 3){
						
					}
						
						shotNum = 0; //Bullet Limit
					HUD.gunFireDetection = true;
				}
			}
		}
		
		//System.out.println("Key Pressed: " + key);
		if(key == KeyEvent.VK_END) System.exit(1);
		
	}
	
	public void keyReleased(KeyEvent e){
	int key = e.getKeyCode();
	
		for(int i = 0; i < handler.object.size(); i++){
			GameObject tempObject = handler.object.get(i);
		
			
				/*if(tempObject.getID() == ID.Player){
				//Key Events for Player1
				
					if(key == KeyEvent.VK_W) tempObject.setVelY(SDNum);
					if(key == KeyEvent.VK_S) tempObject.setVelY(SDNum);
					if(key == KeyEvent.VK_A) tempObject.setVelX(SDNum);
					if(key == KeyEvent.VK_D) tempObject.setVelX(SDNum);
					shotNum = 1;
				}*/
				if(tempObject.getID() == ID.Player){
					//Key Events for Player2
				
				
					if(key == KeyEvent.VK_UP) { keyDown[0]=false; Player.move = 1; }// tempObject.setVelY(0);
					if(key == KeyEvent.VK_DOWN){ keyDown[1]=false; Player.move = 1; }// tempObject.setVelY(0);
					if(key == KeyEvent.VK_LEFT){ keyDown[2]=false; Player.move = 1; }// tempObject.setVelX(0);
					if(key == KeyEvent.VK_RIGHT){ keyDown[3]=false; Player.move = 1; }// tempObject.setVelX(0);
					
					//vertical movement
					if(!keyDown[0] && !keyDown[1]) tempObject.setVelY(0);
					//Horizontal movement
					if(!keyDown[2] && !keyDown[3]) tempObject.setVelX(0);
					
					if(key == KeyEvent.VK_SPACE){
						//Stops 'Hold Down Shooting'
						shotNum = 1;
					}
					
				}
			}
		}
	}





	

