package com.virlaity.src;


import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;


import java.awt.Rectangle;


import javax.swing.ImageIcon;

public class FighterMK1 extends GameObject{

	int hp = 50;

	
	boolean destroy = false;
	boolean playerTF = false;
	float diffX;
	float diffY;
	float distance;
	
	private HUD hud;
	
	private int move = 1;
	//Images
	private double imageNumber = 1;
	private String FighterMK1Image1 = "/images/FighterMK1.png";
	
	private String MK1Idle1 = "/images/FighterMK1-Idle1.png";
	private String MK1Idle2 = "/images/FighterMK1-Idle2.png";
	
	private String MK1MD1 = "/images/FighterMK1-Move1.png";
	private String MK1MD2 = "/images/FighterMK1-Move2.png";
	
	private double imageExplosionNum = 1;
	private String MK1Death1 = "/images/FighterMK1-Death1.png";
	private String MK1Death2 = "/images/FighterMK1-Death2.png";
	private String MK1Death3 = "/images/FighterMK1-Death3.png";
	private String MK1Death4 = "/images/FighterMK1-Death4.png";
	private String MK1Death5 = "/images/FighterMK1-Death5.png";
	private String MK1Death6 = "/images/FighterMK1-Death6.png";
	private String MK1Death7 = "/images/FighterMK1-Death7.png";


	private float num = 0f;
	private int fireNum = 0;
	
	
	//Audio
	private Handler handler;
	private GameObject player;

	
	public FighterMK1(int x, int y, ID id, Handler handler, HUD hud) {
		super(x, y, id);
		this.handler = handler;
		this.hud = hud;
		
		for(int i = 0; i < handler.object.size(); i++){
			 if(handler.object.get(i).getID() == ID.Player){ player = handler.object.get(i); playerTF = true;}
		}
		
		
	}

	public Rectangle getBounds(){
		return new Rectangle((int)x, (int)y, 33, 24);
	}
	
	
	public void tick() {
		x += velX;
		y += velY;

		YXMove();
		MK1Shoot();
		
		collision();
		destroyInstance();

	}
	

	private void YXMove(){
		if (playerTF == true){
		diffX = x - player.getX() + 6;
		diffY = y - player.getY() - 16;
		distance = (float) Math.sqrt((x - player.getX())*(x - player.getX()) + (y- player.getY())* (y - player.getY()));
		}
		
		if( y >= 200){
			num = -0.5f;
			velY = num;
		}else if(y <= 55){
			num = 1f;
			velY = num;
		}if (x >= 300 && playerTF == false){
			velX = -1;
		}else if(x <= 10  && playerTF == false){
			velX = 1;
		}
		if(playerTF == true){
			velX = ((-1 /distance) * diffX * 3);
			velY = num;
		}
		
	}
	
	private void MK1Shoot() {
		fireNum++;
		if(fireNum == 100 && playerTF == true){
			fireNum = 0;
			handler.addObject(new MK1Bullet((int)this.getX() + 15,(int)this.getY() +18, ID.MK1Bullet, handler));
		}
	}
	
	private void collision(){
		for(int i = 0; i < handler.object.size();i++){
			
			GameObject tempObject = handler.object.get(i);
			
			if(tempObject.getID() == ID.Bullet){
				if(getBounds().intersects(tempObject.getBounds()) && (destroy != true)){
					//Collision Code
					handler.removeObject(tempObject);
					hp = hp - Bullet.damage;
					if (hp <= 0){
						hud.score = hud.score + 30;
						destroy = true;
					}
				}
			}
			if(tempObject.getID() == ID.HomingMissile){
				if(getBounds().intersects(tempObject.getBounds()) && (destroy != true)){
					handler.removeObject(tempObject);
					hp = hp - HomingMissile.damage;
					if (hp <= 0){
						hud.score = hud.score + 30;
						destroy = true;
					}
				}
			}
			if(tempObject.getID() == ID.Player){
				if(getBounds().intersects(tempObject.getBounds())){
					handler.removeObject(this);
						HUD.HEALTH -= 50;
				}
			}
		}
	}

	private void destroyInstance(){
		if(y > Game.HEIGHT){
			handler.removeObject(this);
			System.gc();
		}
	}

	public void render(Graphics g) {
		if(num < 0 && destroy == false){
		g.drawImage(getFighterMK1IdleImage(), (int)x, (int)y, null);
		}if(num > 0 && destroy == false){
			g.drawImage(getFighterMK1MDImage(), (int)x,(int) y, null);
	
		}if(destroy == true){
			g.drawImage(explosionAnnimation(), (int)x - 34,(int) y- 35, null);
			//velY = 0;
		}
		
		if(hp < 50 && destroy == false){
		//Back of MK1 Health Bar
		g.setColor(Color.DARK_GRAY);
		g.fillRect((int)x + 4,(int)y - 8,27,7);
		//Health Bar
		g.setColor(Color.red);
		g.fillRect((int)x + 5,(int)y - 7,hp / 2,5);
		}
		
	}

	public Image getFighterMK1IdleImage(){
		if(imageNumber <= 1.9){
			ImageIcon i = new ImageIcon(getClass().getResource(MK1Idle1));
			imageNumber = imageNumber + Game.animationSpeed;
			return i.getImage();
		}else if(imageNumber >1.9 && imageNumber< 2.9){
			ImageIcon i = new ImageIcon(getClass().getResource(MK1Idle2));
			imageNumber = imageNumber  + Game.animationSpeed;
			return i.getImage();
		}else if(imageNumber >=2.9){
			imageNumber = 1;
		}
		return null;
	}
	
	public Image getFighterMK1MDImage(){
		if(imageNumber <= 1.9){
			ImageIcon i = new ImageIcon(getClass().getResource(MK1MD1));
			imageNumber = imageNumber + Game.animationSpeed;
			return i.getImage();
		}else if(imageNumber >1.9 && imageNumber< 2.9){
			ImageIcon i = new ImageIcon(getClass().getResource(MK1MD2));
			imageNumber = imageNumber  + Game.animationSpeed;
			return i.getImage();
		}else if(imageNumber >=2.9){
			imageNumber = 1;
		}
		return null;
	}
	
	private Image explosionAnnimation(){
		if(imageExplosionNum <= 1.9){
			ImageIcon i = new ImageIcon(getClass().getResource(MK1Death1));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if(imageExplosionNum >1.9 && imageExplosionNum< 2.9){
			ImageIcon i = new ImageIcon(getClass().getResource(MK1Death2));
			imageExplosionNum = imageExplosionNum  + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >2.9 && imageExplosionNum < 3.9){
			ImageIcon i = new ImageIcon(getClass().getResource(MK1Death3));
			imageExplosionNum = imageExplosionNum +  Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >3.9 && imageExplosionNum < 4.9){
			ImageIcon i = new ImageIcon(getClass().getResource(MK1Death4));
			imageExplosionNum = imageExplosionNum +Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >4.9 && imageExplosionNum < 5.9){
			ImageIcon i = new ImageIcon(getClass().getResource(MK1Death5));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >5.9 && imageExplosionNum < 6.9){
			ImageIcon i = new ImageIcon(getClass().getResource(MK1Death6));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if (imageExplosionNum >6.9 && imageExplosionNum < 7.9){
			ImageIcon i = new ImageIcon(getClass().getResource(MK1Death7));
			imageExplosionNum = imageExplosionNum + Game.animationSpeed;
			return i.getImage();
		}else if(imageExplosionNum >7.9){
			handler.removeObject(this);
		}
		return null;
		
	}

}

