package com.virlaity.src;

import java.awt.Canvas;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferStrategy;
import java.util.Random;

import javax.swing.ImageIcon;



public class Game extends Canvas implements Runnable{

	private static final long serialVersionUID = 1L;
	
	public static final int WIDTH = 336, HEIGHT = 600;
	
	private Thread thread;
	private boolean running = false;
	

	private Random r;
	private Handler handler;
	private HUD hud;
	private Spawn spawner;
	
	public static double animationSpeed = 0.02;
	
	
	//Backgrounds
	private double BGMDown = 0; // Background Motion Down Lower
	private String background = "/images/TDSBackground1.png";
	private double BGMDown2 = -650; // Background Motion Down upper
	//Backgrounds
	private double BGMDown3 = 0; // Background Motion Down Lower
	private String background1 = "/images/TDSBackground2.png";
	private double BGMDown4 = -650; // Background Motion Down upper
	
	
	public Game(){
		handler = new Handler();
		this.addKeyListener(new KeyInput(handler));
		
		new Window(WIDTH, HEIGHT, "Mission To Mars", this);
		
		hud = new HUD();
		spawner = new Spawn(handler, hud);
		r = new Random();
		
		//Player
  		handler.addObject(new Player(WIDTH/2-64, HEIGHT -(HEIGHT/4), ID.Player)); //Player

	
	}
	
	public synchronized void start(){
		thread = new Thread(this);
		thread.start();
		running = true;
	}
	
	public synchronized void stop(){
		try{
			thread.join();
			running = false;
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void run(){
		setFocusable(true);
	       long lastTime = System.nanoTime();
	        double amountOfTicks = 60.0;
	        double ns = 1000000000 / amountOfTicks;
	        double delta = 0;
	        long timer = System.currentTimeMillis();
	        double frames = 0;
	        while(running)
	        {
	                    long now = System.nanoTime();
	                    delta += (now - lastTime) / ns;
	                    lastTime = now;
	                    while(delta >=1)
	                            {
	                                tick();
	                                delta--;
	                            }
	                            if(running)
	                                render();
	                            frames++;
	                            
	                            if(System.currentTimeMillis() - timer > 1000)
	                            {
	                        		animationSpeed = 14/frames;
	                                timer += 1000;
	                                System.out.println("FPS: "+ frames);
	                                frames = 0;
	                            }
	        }
	                stop();
	}
	
	private void endGame(){
		if(HUD.HEALTH <= 0){
			System.exit(0);
		}
	}
	
	private void tick(){
		handler.tick();
		hud.tick();
		spawner.tick();
		endGame();
		
	}

	private void render(){
		BufferStrategy bs = this.getBufferStrategy();
		if(bs == null){
			this.createBufferStrategy(3);
			return;
		}
		
		Graphics g = bs.getDrawGraphics();
		
		Graphics2D g2d = (Graphics2D) g;
		
		//Background
		 	g2d.drawImage(getBackgroundImage(),0,(int) BGMDown,this);
		 	BGMDown = BGMDown + (animationSpeed + 0.01);
		 	if(BGMDown > 650){
		 		BGMDown = -650;
		 	}
		 	g2d.drawImage(getBackgroundImage2(),0,(int) BGMDown2,this);
		 		BGMDown2 = BGMDown2 +(animationSpeed + 0.01);
		 		if(BGMDown2 > 650){
		 			BGMDown2 = -650;
		 	}
		 		
		//Background 2
			 g2d.drawImage(getBackgroundImage3(),0,(int) BGMDown3,this);
			 BGMDown3 = BGMDown3 + 0.8;
			 if(BGMDown3 > 650){
			 	BGMDown3 = -650;
			 }
			 g2d.drawImage(getBackgroundImage4(),0,(int) BGMDown4,this);
			 	BGMDown4 = BGMDown4 + 0.8;
			 	if(BGMDown4 > 650){
			 		BGMDown4 = -650;
			 }	
			 	
			 	
		handler.render(g); 		
		
		hud.render(g);
			
		g.dispose();
		bs.show();
	}
	
	public static float clamp(float var, float min, float max){
		if(var >= max)
			return var = max;
		else if (var <= min)
			return var = min;
		else
		return var;
	}
	
	//Background Lower
	public Image getBackgroundImage(){
		ImageIcon i = new ImageIcon(getClass().getResource(background));
		return i.getImage();
	}
	
	//Background Upper
	public Image getBackgroundImage2(){
		ImageIcon i = new ImageIcon(getClass().getResource(background));
		return i.getImage();
	}
	
	//Background Lower
	public Image getBackgroundImage3(){
		ImageIcon i = new ImageIcon(getClass().getResource(background1));
		return i.getImage();
	}
	
	//Background Upper
	public Image getBackgroundImage4(){
		ImageIcon i = new ImageIcon(getClass().getResource(background1));
		return i.getImage();
	}
	
	public static void main(String args[]){
		new Game();
	}

}
